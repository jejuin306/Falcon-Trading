import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { recallApi } from '@/services/recall-api';

export function useRecallApi() {
  const refreshData = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/refresh', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      
      if (!response.ok) {
        throw new Error('Failed to refresh data');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate all queries to refetch fresh data
      queryClient.invalidateQueries();
    },
  });

  const executeTrade = useMutation({
    mutationFn: async (tradeData: {
      pair: string;
      type: string;
      amount: string;
      price: string;
      reason: string;
    }) => {
      const response = await fetch('/api/trades', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(tradeData),
      });
      
      if (!response.ok) {
        const error = await response.text();
        throw new Error(`Failed to execute trade: ${error}`);
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
      queryClient.invalidateQueries({ queryKey: ['/api/trades'] });
      queryClient.invalidateQueries({ queryKey: ['/api/positions'] });
    },
  });

  return {
    refreshData,
    executeTrade,
    isRecallConfigured: recallApi.isConfigured(),
  };
}

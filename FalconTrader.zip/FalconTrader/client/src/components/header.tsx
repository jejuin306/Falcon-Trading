import falconLogo from "@assets/S6Q05TY0_400x400_1756012753747.png";

interface HeaderProps {
  portfolio?: any;
  competitionData?: any;
  systemStatus?: any;
  isConnected: boolean;
  onRefresh: () => void;
  isRefreshing: boolean;
}

export default function Header({
  portfolio,
  competitionData,
  systemStatus,
  isConnected,
  onRefresh,
  isRefreshing
}: HeaderProps) {
  return (
    <header className="bg-dark-800 border-b border-dark-700 px-4 py-3 sticky top-0 z-50">
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        {/* Logo and Brand */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <img 
              src={falconLogo}
              alt="Falcon Trading Logo" 
              className="w-10 h-10 rounded-lg"
            />
            <div>
              <h1 className="text-xl font-bold text-white" data-testid="text-brand-title">Falcon Trading</h1>
              <p className="text-sm text-dark-400" data-testid="text-brand-subtitle">Smart Momentum Trader</p>
            </div>
          </div>
        </div>

        {/* Key Metrics Bar */}
        <div className="hidden lg:flex items-center space-x-6">
          <div className="text-center">
            <p className="text-xs text-dark-400">Portfolio Value</p>
            <p className="text-lg font-semibold text-emerald-400" data-testid="text-portfolio-value">
              ${portfolio?.totalValue ? parseFloat(portfolio.totalValue).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00'}
            </p>
          </div>
          <div className="text-center">
            <p className="text-xs text-dark-400">Daily P&L</p>
            <p className="text-lg font-semibold text-emerald-400" data-testid="text-daily-pnl">
              +{portfolio?.dailyPnL || '0.00'}%
            </p>
          </div>
          <div className="text-center">
            <p className="text-xs text-dark-400">Open Positions</p>
            <p className="text-lg font-semibold text-primary-500" data-testid="text-open-positions">
              {portfolio?.openPositions || 0}/{portfolio?.maxPositions || 5}
            </p>
          </div>
          <div className="text-center">
            <p className="text-xs text-dark-400">Competition Rank</p>
            <p className="text-lg font-semibold text-purple-400" data-testid="text-competition-rank">
              #{competitionData?.currentRank || 'N/A'}
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-3">
          <button 
            onClick={onRefresh}
            disabled={isRefreshing}
            className="p-2 text-dark-400 hover:text-white transition-colors disabled:opacity-50"
            data-testid="button-refresh"
          >
            <i className={`fas fa-sync-alt text-sm ${isRefreshing ? 'animate-spin' : ''}`}></i>
          </button>
          <button className="p-2 text-dark-400 hover:text-white transition-colors" data-testid="button-settings">
            <i className="fas fa-cog text-sm"></i>
          </button>
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'}`}></div>
            <span className={`text-xs ${isConnected ? 'text-emerald-400' : 'text-red-400'}`} data-testid="text-connection-status">
              {isConnected ? 'Live' : 'Disconnected'}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}

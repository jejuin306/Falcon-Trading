import TradeLog from './trade-log';

interface SidebarProps {
  strategyConfig?: any;
  riskMetrics?: any;
  recentTrades?: any[];
}

export default function Sidebar({ strategyConfig, riskMetrics, recentTrades }: SidebarProps) {
  return (
    <aside className="w-80 bg-dark-800 border-r border-dark-700 flex flex-col hidden lg:flex">
      {/* Strategy Status */}
      <div className="p-4 border-b border-dark-700">
        <h3 className="text-sm font-semibold text-dark-300 mb-3" data-testid="text-strategy-title">Strategy Status</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-dark-400">Status</span>
            <span className={`px-2 py-1 text-xs rounded-full ${
              strategyConfig?.isActive 
                ? 'bg-emerald-900 text-emerald-300' 
                : 'bg-red-900 text-red-300'
            }`} data-testid="text-strategy-status">
              {strategyConfig?.isActive ? 'Active' : 'Inactive'}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-dark-400">Fast SMA</span>
            <span className="text-sm text-white" data-testid="text-fast-sma">{strategyConfig?.fastSMA || 12}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-dark-400">Slow SMA</span>
            <span className="text-sm text-white" data-testid="text-slow-sma">{strategyConfig?.slowSMA || 26}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-dark-400">ATR Period</span>
            <span className="text-sm text-white" data-testid="text-atr-period">{strategyConfig?.atrPeriod || 14}</span>
          </div>
        </div>
      </div>

      {/* Risk Management */}
      <div className="p-4 border-b border-dark-700">
        <h3 className="text-sm font-semibold text-dark-300 mb-3" data-testid="text-risk-title">Risk Management</h3>
        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-dark-400">Max Risk per Trade</span>
              <span className="text-white" data-testid="text-max-risk-per-trade">
                {strategyConfig?.maxRiskPerTrade || 1}%
              </span>
            </div>
            <div className="w-full bg-dark-700 rounded-full h-2">
              <div 
                className="bg-primary-500 h-2 rounded-full" 
                style={{ 
                  width: `${Math.min((parseFloat(riskMetrics?.currentRiskPerTrade || '0.6') / parseFloat(strategyConfig?.maxRiskPerTrade || '1')) * 100, 100)}%` 
                }}
                data-testid="progress-risk-per-trade"
              ></div>
            </div>
          </div>
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-dark-400">Daily Loss Limit</span>
              <span className="text-white" data-testid="text-daily-loss-limit">
                {riskMetrics?.dailyLossPercent || '0'}% / {strategyConfig?.dailyLossLimit || 5}%
              </span>
            </div>
            <div className="w-full bg-dark-700 rounded-full h-2">
              <div 
                className="bg-amber-500 h-2 rounded-full" 
                style={{ 
                  width: `${Math.min((parseFloat(riskMetrics?.dailyLossPercent || '0') / parseFloat(strategyConfig?.dailyLossLimit || '5')) * 100, 100)}%` 
                }}
                data-testid="progress-daily-loss"
              ></div>
            </div>
          </div>
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-dark-400">Position Slots</span>
              <span className="text-white" data-testid="text-position-slots">
                {riskMetrics?.positionSlots || 0} / 5
              </span>
            </div>
            <div className="w-full bg-dark-700 rounded-full h-2">
              <div 
                className="bg-purple-500 h-2 rounded-full" 
                style={{ 
                  width: `${((riskMetrics?.positionSlots || 0) / 5) * 100}%` 
                }}
                data-testid="progress-position-slots"
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Trades Log */}
      <div className="flex-1 p-4 overflow-hidden">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-sm font-semibold text-dark-300" data-testid="text-trades-title">Live Trades</h3>
          <span className="text-xs text-dark-400" data-testid="text-trades-count">
            {recentTrades?.length || 0} today
          </span>
        </div>
        <TradeLog trades={recentTrades} />
      </div>
    </aside>
  );
}

interface StatsGridProps {
  riskMetrics?: any;
  competitionData?: any;
  positions?: any[];
  systemStatus?: any;
}

export default function StatsGrid({ riskMetrics, competitionData, positions, systemStatus }: StatsGridProps) {
  const formatTimeAgo = (timestamp: string | Date) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffMs = now.getTime() - time.getTime();
    const diffSecs = Math.floor(diffMs / 1000);
    
    if (diffSecs < 60) return `${diffSecs}s ago`;
    
    const diffMins = Math.floor(diffSecs / 60);
    return `${diffMins}m ago`;
  };

  const getStatusIndicator = (status: string) => {
    const isOnline = status === 'online' || status === 'live';
    return (
      <div className="flex items-center space-x-1">
        <div className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-400' : 'bg-red-400'}`}></div>
        <span className={`text-xs ${isOnline ? 'text-emerald-400' : 'text-red-400'}`}>
          {isOnline ? 'Online' : 'Offline'}
        </span>
      </div>
    );
  };

  const formatPnL = (value: string, isPercent: boolean = false) => {
    const num = parseFloat(value || '0');
    const sign = num >= 0 ? '+' : '';
    const color = num >= 0 ? 'text-emerald-400' : 'text-red-400';
    return (
      <span className={`text-xs ${color}`}>
        {sign}{num.toFixed(isPercent ? 1 : 2)}{isPercent ? '%' : ''}
      </span>
    );
  };

  return (
    <div className="p-4 pt-0">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Performance Metrics */}
        <div className="bg-dark-800 rounded-lg border border-dark-700 p-4" data-testid="card-performance-metrics">
          <h3 className="text-sm font-semibold text-dark-300 mb-3">Performance</h3>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-xs text-dark-400">Win Rate</span>
              <span className="text-xs text-emerald-400" data-testid="text-win-rate">
                {riskMetrics?.winRate || '0.0'}%
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-xs text-dark-400">Sharpe Ratio</span>
              <span className="text-xs text-white" data-testid="text-sharpe-ratio">
                {riskMetrics?.sharpeRatio || '0.00'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-xs text-dark-400">Max Drawdown</span>
              <span className="text-xs text-red-400" data-testid="text-max-drawdown">
                {riskMetrics?.maxDrawdown || '0.0'}%
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-xs text-dark-400">Profit Factor</span>
              <span className="text-xs text-emerald-400" data-testid="text-profit-factor">
                {riskMetrics?.profitFactor || '0.00'}
              </span>
            </div>
          </div>
        </div>

        {/* Competition Standing */}
        <div className="bg-dark-800 rounded-lg border border-dark-700 p-4" data-testid="card-competition-standing">
          <h3 className="text-sm font-semibold text-dark-300 mb-3">Competition</h3>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-xs text-dark-400">Current Rank</span>
              <span className="text-xs text-purple-400" data-testid="text-current-rank">
                #{competitionData?.currentRank || 'N/A'} / {competitionData?.totalParticipants || 'N/A'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-xs text-dark-400">Days Remaining</span>
              <span className="text-xs text-white" data-testid="text-days-remaining">
                {competitionData?.daysRemaining || '0.0'} days
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-xs text-dark-400">Prize Pool</span>
              <span className="text-xs text-amber-400" data-testid="text-prize-pool">
                ${competitionData?.prizePool ? parseFloat(competitionData.prizePool).toLocaleString() : '0'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-xs text-dark-400">Leader P&L</span>
              <span className="text-xs text-emerald-400" data-testid="text-leader-pnl">
                +${competitionData?.leaderPnL ? parseFloat(competitionData.leaderPnL).toLocaleString() : '0'}
              </span>
            </div>
          </div>
        </div>

        {/* Open Positions */}
        <div className="bg-dark-800 rounded-lg border border-dark-700 p-4" data-testid="card-open-positions">
          <h3 className="text-sm font-semibold text-dark-300 mb-3">Open Positions</h3>
          <div className="space-y-2">
            {positions && positions.length > 0 ? (
              positions.slice(0, 3).map((position, index) => (
                <div key={position.id || index} className="flex justify-between items-center" data-testid={`row-position-${index}`}>
                  <div>
                    <span className="text-xs text-white" data-testid={`text-position-pair-${index}`}>
                      {position.pair}
                    </span>
                    <p className="text-xs text-dark-400" data-testid={`text-position-amount-${index}`}>
                      {parseFloat(position.amount).toFixed(4)}
                    </p>
                  </div>
                  <span data-testid={`text-position-pnl-${index}`}>
                    {formatPnL(position.unrealizedPnLPercent, true)}
                  </span>
                </div>
              ))
            ) : (
              <div className="text-center py-4">
                <p className="text-xs text-dark-400">No open positions</p>
              </div>
            )}
          </div>
        </div>

        {/* System Status */}
        <div className="bg-dark-800 rounded-lg border border-dark-700 p-4" data-testid="card-system-status">
          <h3 className="text-sm font-semibold text-dark-300 mb-3">System Status</h3>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-xs text-dark-400">Recall API</span>
              <div data-testid="status-recall-api">
                {getStatusIndicator(systemStatus?.recallApiStatus || 'offline')}
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-xs text-dark-400">Market Data</span>
              <div data-testid="status-market-data">
                {getStatusIndicator(systemStatus?.marketDataStatus || 'offline')}
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-xs text-dark-400">Last Update</span>
              <span className="text-xs text-white" data-testid="text-last-update">
                {systemStatus?.lastUpdate ? formatTimeAgo(systemStatus.lastUpdate) : 'Never'}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-xs text-dark-400">Latency</span>
              <span className="text-xs text-emerald-400" data-testid="text-latency">
                {systemStatus?.latencyMs || 0}ms
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

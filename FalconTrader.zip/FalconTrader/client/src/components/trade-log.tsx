interface Trade {
  id: string;
  pair: string;
  type: string;
  amount: string;
  price: string;
  status: string;
  reason: string;
  executedAt: string;
}

interface TradeLogProps {
  trades?: Trade[];
}

export default function TradeLog({ trades = [] }: TradeLogProps) {
  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const tradeTime = new Date(timestamp);
    const diffMs = now.getTime() - tradeTime.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'just now';
    if (diffMins < 60) return `${diffMins} min${diffMins === 1 ? '' : 's'} ago`;
    
    const diffHours = Math.floor(diffMins / 60);
    return `${diffHours} hour${diffHours === 1 ? '' : 's'} ago`;
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'executed':
        return 'bg-emerald-900 text-emerald-300';
      case 'pending':
        return 'bg-amber-900 text-amber-300';
      case 'failed':
        return 'bg-red-900 text-red-300';
      case 'stopped':
        return 'bg-red-900 text-red-300';
      default:
        return 'bg-dark-600 text-dark-300';
    }
  };

  const formatTradeAmount = (amount: string, price: string) => {
    const amountNum = parseFloat(amount);
    const priceNum = parseFloat(price);
    const totalValue = amountNum * priceNum;
    
    return `${amountNum.toFixed(4)} (${totalValue.toLocaleString('en-US', {
      style: 'currency',
      currency: 'USD'
    })})`;
  };

  if (!trades.length) {
    return (
      <div className="text-center py-8 text-dark-500">
        <i className="fas fa-chart-line text-2xl mb-2"></i>
        <p className="text-sm">No trades executed yet</p>
      </div>
    );
  }

  return (
    <div className="space-y-3 overflow-y-auto max-h-96" data-testid="container-trade-log">
      {trades.map((trade) => (
        <div 
          key={trade.id}
          className="bg-dark-700 rounded-lg p-3 border border-dark-600"
          data-testid={`card-trade-${trade.id}`}
        >
          <div className="flex justify-between items-start mb-2">
            <div>
              <p className="text-sm font-medium text-white" data-testid={`text-trade-pair-${trade.id}`}>
                {trade.type.toUpperCase()} {trade.pair}
              </p>
              <p className="text-xs text-dark-400" data-testid={`text-trade-time-${trade.id}`}>
                {formatTimeAgo(trade.executedAt)}
              </p>
            </div>
            <span 
              className={`text-xs px-2 py-1 rounded ${getStatusColor(trade.status)}`}
              data-testid={`status-trade-${trade.id}`}
            >
              {trade.status}
            </span>
          </div>
          <p className="text-xs text-dark-400 mb-2" data-testid={`text-trade-amount-${trade.id}`}>
            Amount: {formatTradeAmount(trade.amount, trade.price)}
          </p>
          <p className="text-xs text-dark-300" data-testid={`text-trade-reason-${trade.id}`}>
            Reason: {trade.reason}
          </p>
        </div>
      ))}
    </div>
  );
}

import { useQuery } from '@tanstack/react-query';
import { useWebSocket } from '@/hooks/use-websocket';
import { useRecallApi } from '@/hooks/use-recall-api';
import { useState, useEffect } from 'react';
import Header from '@/components/header';
import Sidebar from '@/components/sidebar';
import ChartArea from '@/components/chart-area';
import StatsGrid from '@/components/stats-grid';

interface DashboardData {
  portfolio: any;
  positions: any[];
  recentTrades: any[];
  strategyConfig: any;
  riskMetrics: any;
  competitionData: any;
  systemStatus: any;
}

export default function Dashboard() {
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const { refreshData } = useRecallApi();

  // Fetch initial dashboard data
  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/dashboard'],
    refetchInterval: 30000, // Refetch every 30 seconds as fallback
  });

  // WebSocket for real-time updates
  const { isConnected, lastMessage } = useWebSocket((message) => {
    if (message.type === 'DATA_UPDATE') {
      setDashboardData(message.payload);
    } else if (message.type === 'TRADE_EXECUTED') {
      // Handle individual trade updates
      console.log('Trade executed:', message.payload);
    }
  });

  // Update dashboard data when initial query loads
  useEffect(() => {
    if (data) {
      setDashboardData(data);
    }
  }, [data]);

  const handleRefresh = () => {
    refreshData.mutate();
  };

  if (isLoading && !dashboardData) {
    return (
      <div className="min-h-screen bg-dark-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-500 mx-auto mb-4"></div>
          <p className="text-dark-400">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (error && !dashboardData) {
    return (
      <div className="min-h-screen bg-dark-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="text-red-400 mb-4">
            <i className="fas fa-exclamation-triangle text-4xl"></i>
          </div>
          <p className="text-red-400 mb-4">Failed to load dashboard data</p>
          <button
            onClick={handleRefresh}
            className="px-4 py-2 bg-primary-600 hover:bg-primary-700 rounded-lg transition-colors"
            data-testid="button-retry"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  const currentData = dashboardData || data;

  return (
    <div className="min-h-screen flex flex-col bg-dark-900">
      <Header
        portfolio={currentData?.portfolio}
        competitionData={currentData?.competitionData}
        systemStatus={currentData?.systemStatus}
        isConnected={isConnected}
        onRefresh={handleRefresh}
        isRefreshing={refreshData.isPending}
      />
      
      <main className="flex-1 flex overflow-hidden">
        <Sidebar
          strategyConfig={currentData?.strategyConfig}
          riskMetrics={currentData?.riskMetrics}
          recentTrades={currentData?.recentTrades}
        />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          <ChartArea portfolio={currentData?.portfolio} />
          <StatsGrid
            riskMetrics={currentData?.riskMetrics}
            competitionData={currentData?.competitionData}
            positions={currentData?.positions}
            systemStatus={currentData?.systemStatus}
          />
        </div>
      </main>
      
      {/* Mobile Bottom Navigation */}
      <div className="lg:hidden fixed bottom-4 left-4 right-4 bg-dark-800 rounded-lg border border-dark-700 p-4">
        <div className="grid grid-cols-4 gap-4 text-center">
          <div>
            <p className="text-xs text-dark-400">Portfolio</p>
            <p className="text-sm font-semibold text-emerald-400" data-testid="text-mobile-portfolio">
              ${currentData?.portfolio?.totalValue ? parseFloat(currentData.portfolio.totalValue).toFixed(0) + 'K' : 'N/A'}
            </p>
          </div>
          <div>
            <p className="text-xs text-dark-400">Daily P&L</p>
            <p className="text-sm font-semibold text-emerald-400" data-testid="text-mobile-pnl">
              +{currentData?.portfolio?.dailyPnL || '0.00'}%
            </p>
          </div>
          <div>
            <p className="text-xs text-dark-400">Positions</p>
            <p className="text-sm font-semibold text-primary-500" data-testid="text-mobile-positions">
              {currentData?.portfolio?.openPositions || 0}/{currentData?.portfolio?.maxPositions || 5}
            </p>
          </div>
          <div>
            <p className="text-xs text-dark-400">Rank</p>
            <p className="text-sm font-semibold text-purple-400" data-testid="text-mobile-rank">
              #{currentData?.competitionData?.currentRank || 'N/A'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

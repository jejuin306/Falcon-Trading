const RECALL_API_BASE = import.meta.env.VITE_RECALL_API_URL || "https://api.sandbox.competitions.recall.network";
const RECALL_API_KEY = import.meta.env.VITE_RECALL_API_KEY;

export interface RecallTradeRequest {
  fromToken: string;
  toToken: string;
  amount: string;
  reason: string;
}

export interface RecallTradeResponse {
  success: boolean;
  transactionId: string;
  executedAmount: string;
  executedPrice: string;
  timestamp: string;
}

export class RecallApiService {
  private apiKey: string;
  private baseUrl: string;

  constructor() {
    this.apiKey = RECALL_API_KEY || "";
    this.baseUrl = RECALL_API_BASE;
  }

  private getHeaders() {
    return {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${this.apiKey}`,
    };
  }

  async executeTrade(request: RecallTradeRequest): Promise<RecallTradeResponse> {
    if (!this.apiKey) {
      throw new Error("Recall API key not configured");
    }

    try {
      const response = await fetch(`${this.baseUrl}/api/trade/execute`, {
        method: "POST",
        headers: this.getHeaders(),
        body: JSON.stringify(request),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Recall API error (${response.status}): ${errorText}`);
      }

      return await response.json();
    } catch (error) {
      console.error("Recall API trade execution failed:", error);
      throw error;
    }
  }

  async getPortfolioData(): Promise<any> {
    if (!this.apiKey) {
      throw new Error("Recall API key not configured");
    }

    try {
      const response = await fetch(`${this.baseUrl}/api/portfolio`, {
        method: "GET",
        headers: this.getHeaders(),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Recall API error (${response.status}): ${errorText}`);
      }

      return await response.json();
    } catch (error) {
      console.error("Recall API portfolio fetch failed:", error);
      throw error;
    }
  }

  async getCompetitionData(): Promise<any> {
    if (!this.apiKey) {
      throw new Error("Recall API key not configured");
    }

    try {
      const response = await fetch(`${this.baseUrl}/api/competition`, {
        method: "GET",
        headers: this.getHeaders(),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Recall API error (${response.status}): ${errorText}`);
      }

      return await response.json();
    } catch (error) {
      console.error("Recall API competition fetch failed:", error);
      throw error;
    }
  }

  isConfigured(): boolean {
    return !!this.apiKey;
  }
}

export const recallApi = new RecallApiService();

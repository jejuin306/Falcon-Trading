import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertTradeSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Store connected clients
  const clients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    clients.add(ws);
    
    ws.on('close', () => {
      clients.delete(ws);
    });

    // Send initial data
    sendDataUpdate(ws);
  });

  // Broadcast to all connected clients
  function broadcast(data: any) {
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(data));
      }
    });
  }

  // Send data update to specific client or broadcast
  async function sendDataUpdate(ws?: WebSocket) {
    try {
      const data = {
        type: 'DATA_UPDATE',
        payload: {
          portfolio: await storage.getPortfolio(),
          positions: await storage.getOpenPositions(),
          recentTrades: await storage.getRecentTrades(10),
          strategyConfig: await storage.getStrategyConfig(),
          riskMetrics: await storage.getRiskMetrics(),
          competitionData: await storage.getCompetitionData(),
          systemStatus: await storage.getSystemStatus(),
        }
      };

      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(data));
      } else {
        broadcast(data);
      }
    } catch (error) {
      console.error('Error sending data update:', error);
    }
  }

  // API Routes
  
  // Get dashboard data
  app.get("/api/dashboard", async (req, res) => {
    try {
      const data = {
        portfolio: await storage.getPortfolio(),
        positions: await storage.getOpenPositions(),
        recentTrades: await storage.getRecentTrades(10),
        strategyConfig: await storage.getStrategyConfig(),
        riskMetrics: await storage.getRiskMetrics(),
        competitionData: await storage.getCompetitionData(),
        systemStatus: await storage.getSystemStatus(),
      };
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch dashboard data" });
    }
  });

  // Get all trades
  app.get("/api/trades", async (req, res) => {
    try {
      const trades = await storage.getTrades();
      res.json(trades);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch trades" });
    }
  });

  // Execute new trade (integration with Recall API)
  app.post("/api/trades", async (req, res) => {
    try {
      const tradeData = insertTradeSchema.parse(req.body);
      
      // TODO: In production, integrate with Recall Network API here
      // const recallResponse = await recallApi.executeTrade(tradeData);
      
      const trade = await storage.createTrade({
        ...tradeData,
        status: "EXECUTED", // Would come from Recall API response
        recallTxId: `recall_tx_${Date.now()}`, // Would come from Recall API
      });

      // Broadcast trade update
      broadcast({
        type: 'TRADE_EXECUTED',
        payload: trade
      });

      // Update portfolio and positions based on trade
      await updatePortfolioAfterTrade(trade);

      res.json(trade);
    } catch (error) {
      console.error("Trade execution error:", error);
      res.status(400).json({ error: "Failed to execute trade" });
    }
  });

  // Get positions
  app.get("/api/positions", async (req, res) => {
    try {
      const positions = await storage.getOpenPositions();
      res.json(positions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch positions" });
    }
  });

  // Update strategy configuration
  app.put("/api/strategy", async (req, res) => {
    try {
      const config = await storage.updateStrategyConfig(req.body);
      
      // Broadcast strategy update
      broadcast({
        type: 'STRATEGY_UPDATED',
        payload: config
      });
      
      res.json(config);
    } catch (error) {
      res.status(400).json({ error: "Failed to update strategy" });
    }
  });

  // Refresh data from Recall API
  app.post("/api/refresh", async (req, res) => {
    try {
      // TODO: In production, fetch latest data from Recall Network API
      // const recallData = await recallApi.getPortfolioData();
      // await storage.updatePortfolio(recallData.portfolio);
      // await storage.updateCompetitionData(recallData.competition);

      // Update system status
      await storage.updateSystemStatus({
        recallApiStatus: "online",
        marketDataStatus: "live",
        latencyMs: Math.floor(Math.random() * 50) + 10,
      });

      // Send updated data to all clients
      await sendDataUpdate();

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to refresh data" });
    }
  });

  // Helper function to update portfolio after trade execution
  async function updatePortfolioAfterTrade(trade: any) {
    try {
      const currentPortfolio = await storage.getPortfolio();
      if (!currentPortfolio) return;

      // Simulate portfolio value update based on trade
      const tradeValue = parseFloat(trade.amount) * parseFloat(trade.price);
      const newTotalValue = parseFloat(currentPortfolio.totalValue) + 
        (trade.type === 'BUY' ? -tradeValue : tradeValue);

      await storage.updatePortfolio({
        totalValue: newTotalValue.toString(),
        dailyPnL: currentPortfolio.dailyPnL,
        totalReturn: currentPortfolio.totalReturn,
        totalReturnPercent: currentPortfolio.totalReturnPercent,
        openPositions: currentPortfolio.openPositions,
        maxPositions: currentPortfolio.maxPositions,
      });

      // Send updated portfolio data
      await sendDataUpdate();
    } catch (error) {
      console.error('Error updating portfolio after trade:', error);
    }
  }

  // Periodic data updates (simulate market data changes)
  setInterval(async () => {
    try {
      // Update system status with current timestamp
      await storage.updateSystemStatus({
        recallApiStatus: "online",
        marketDataStatus: "live",
        latencyMs: Math.floor(Math.random() * 50) + 10,
      });

      // Simulate small portfolio changes for demo
      const portfolio = await storage.getPortfolio();
      if (portfolio) {
        const change = (Math.random() - 0.5) * 0.1; // Small random change
        const newDailyPnL = (parseFloat(portfolio.dailyPnL) + change).toFixed(2);
        
        await storage.updatePortfolio({
          ...portfolio,
          dailyPnL: newDailyPnL,
        });
      }

      // Send periodic updates
      await sendDataUpdate();
    } catch (error) {
      console.error('Error in periodic update:', error);
    }
  }, 5000); // Every 5 seconds

  return httpServer;
}

async function updatePortfolioAfterTrade(trade: any) {
  // Implementation moved to inside registerRoutes function
}

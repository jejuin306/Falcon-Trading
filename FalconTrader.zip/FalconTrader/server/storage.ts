import {
  type Trade, type InsertTrade,
  type Portfolio, type InsertPortfolio,
  type Position, type InsertPosition,
  type StrategyConfig, type InsertStrategyConfig,
  type RiskMetrics, type InsertRiskMetrics,
  type CompetitionData, type InsertCompetitionData,
  type MarketData, type InsertMarketData,
  type SystemStatus, type InsertSystemStatus
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Trades
  getTrades(): Promise<Trade[]>;
  getRecentTrades(limit?: number): Promise<Trade[]>;
  createTrade(trade: InsertTrade): Promise<Trade>;

  // Portfolio
  getPortfolio(): Promise<Portfolio | undefined>;
  updatePortfolio(portfolio: InsertPortfolio): Promise<Portfolio>;

  // Positions
  getPositions(): Promise<Position[]>;
  getOpenPositions(): Promise<Position[]>;
  createPosition(position: InsertPosition): Promise<Position>;
  updatePosition(id: string, updates: Partial<Position>): Promise<Position>;
  closePosition(id: string): Promise<void>;

  // Strategy
  getStrategyConfig(): Promise<StrategyConfig | undefined>;
  updateStrategyConfig(config: InsertStrategyConfig): Promise<StrategyConfig>;

  // Risk Metrics
  getRiskMetrics(): Promise<RiskMetrics | undefined>;
  updateRiskMetrics(metrics: InsertRiskMetrics): Promise<RiskMetrics>;

  // Competition
  getCompetitionData(): Promise<CompetitionData | undefined>;
  updateCompetitionData(data: InsertCompetitionData): Promise<CompetitionData>;

  // Market Data
  getMarketData(pair?: string): Promise<MarketData[]>;
  updateMarketData(data: InsertMarketData): Promise<MarketData>;

  // System Status
  getSystemStatus(): Promise<SystemStatus | undefined>;
  updateSystemStatus(status: InsertSystemStatus): Promise<SystemStatus>;
}

export class MemStorage implements IStorage {
  private trades: Map<string, Trade>;
  private portfolio: Portfolio | undefined;
  private positions: Map<string, Position>;
  private strategyConfig: StrategyConfig | undefined;
  private riskMetrics: RiskMetrics | undefined;
  private competitionData: CompetitionData | undefined;
  private marketData: Map<string, MarketData>;
  private systemStatus: SystemStatus | undefined;

  constructor() {
    this.trades = new Map();
    this.positions = new Map();
    this.marketData = new Map();
    
    // Initialize with default data
    this.initializeDefaults();
  }

  private initializeDefaults() {
    // Initialize portfolio
    this.portfolio = {
      id: randomUUID(),
      totalValue: "12847.32",
      dailyPnL: "2.34",
      totalReturn: "2847.32",
      totalReturnPercent: "28.47",
      openPositions: 3,
      maxPositions: 5,
      updatedAt: new Date(),
    };

    // Initialize strategy config
    this.strategyConfig = {
      id: randomUUID(),
      isActive: true,
      fastSMA: 12,
      slowSMA: 26,
      atrPeriod: 14,
      maxRiskPerTrade: "1.0",
      dailyLossLimit: "5.0",
      updatedAt: new Date(),
    };

    // Initialize risk metrics
    this.riskMetrics = {
      id: randomUUID(),
      currentRiskPerTrade: "0.6",
      dailyLossPercent: "1.2",
      positionSlots: 3,
      maxDrawdown: "-3.2",
      sharpeRatio: "1.47",
      winRate: "68.3",
      profitFactor: "2.14",
      updatedAt: new Date(),
    };

    // Initialize competition data
    this.competitionData = {
      id: randomUUID(),
      currentRank: 7,
      totalParticipants: 234,
      daysRemaining: "4.2",
      leaderPnL: "4231.87",
      prizePool: "10000",
      updatedAt: new Date(),
    };

    // Initialize system status
    this.systemStatus = {
      id: randomUUID(),
      recallApiStatus: "online",
      marketDataStatus: "live",
      lastUpdate: new Date(),
      latencyMs: 12,
    };
  }

  async getTrades(): Promise<Trade[]> {
    return Array.from(this.trades.values()).sort((a, b) => 
      new Date(b.executedAt!).getTime() - new Date(a.executedAt!).getTime()
    );
  }

  async getRecentTrades(limit: number = 10): Promise<Trade[]> {
    const trades = await this.getTrades();
    return trades.slice(0, limit);
  }

  async createTrade(insertTrade: InsertTrade): Promise<Trade> {
    const id = randomUUID();
    const trade: Trade = {
      ...insertTrade,
      id,
      executedAt: new Date(),
    };
    this.trades.set(id, trade);
    return trade;
  }

  async getPortfolio(): Promise<Portfolio | undefined> {
    return this.portfolio;
  }

  async updatePortfolio(portfolioData: InsertPortfolio): Promise<Portfolio> {
    if (this.portfolio) {
      this.portfolio = {
        ...this.portfolio,
        ...portfolioData,
        updatedAt: new Date(),
      };
    } else {
      this.portfolio = {
        id: randomUUID(),
        ...portfolioData,
        updatedAt: new Date(),
      };
    }
    return this.portfolio;
  }

  async getPositions(): Promise<Position[]> {
    return Array.from(this.positions.values());
  }

  async getOpenPositions(): Promise<Position[]> {
    return Array.from(this.positions.values());
  }

  async createPosition(insertPosition: InsertPosition): Promise<Position> {
    const id = randomUUID();
    const position: Position = {
      ...insertPosition,
      id,
      openedAt: new Date(),
    };
    this.positions.set(id, position);
    return position;
  }

  async updatePosition(id: string, updates: Partial<Position>): Promise<Position> {
    const position = this.positions.get(id);
    if (!position) throw new Error(`Position ${id} not found`);
    
    const updated = { ...position, ...updates };
    this.positions.set(id, updated);
    return updated;
  }

  async closePosition(id: string): Promise<void> {
    this.positions.delete(id);
  }

  async getStrategyConfig(): Promise<StrategyConfig | undefined> {
    return this.strategyConfig;
  }

  async updateStrategyConfig(config: InsertStrategyConfig): Promise<StrategyConfig> {
    if (this.strategyConfig) {
      this.strategyConfig = {
        ...this.strategyConfig,
        ...config,
        updatedAt: new Date(),
      };
    } else {
      this.strategyConfig = {
        id: randomUUID(),
        ...config,
        updatedAt: new Date(),
      };
    }
    return this.strategyConfig;
  }

  async getRiskMetrics(): Promise<RiskMetrics | undefined> {
    return this.riskMetrics;
  }

  async updateRiskMetrics(metrics: InsertRiskMetrics): Promise<RiskMetrics> {
    if (this.riskMetrics) {
      this.riskMetrics = {
        ...this.riskMetrics,
        ...metrics,
        updatedAt: new Date(),
      };
    } else {
      this.riskMetrics = {
        id: randomUUID(),
        ...metrics,
        updatedAt: new Date(),
      };
    }
    return this.riskMetrics;
  }

  async getCompetitionData(): Promise<CompetitionData | undefined> {
    return this.competitionData;
  }

  async updateCompetitionData(data: InsertCompetitionData): Promise<CompetitionData> {
    if (this.competitionData) {
      this.competitionData = {
        ...this.competitionData,
        ...data,
        updatedAt: new Date(),
      };
    } else {
      this.competitionData = {
        id: randomUUID(),
        ...data,
        updatedAt: new Date(),
      };
    }
    return this.competitionData;
  }

  async getMarketData(pair?: string): Promise<MarketData[]> {
    const data = Array.from(this.marketData.values());
    return pair ? data.filter(d => d.pair === pair) : data;
  }

  async updateMarketData(data: InsertMarketData): Promise<MarketData> {
    const id = randomUUID();
    const marketData: MarketData = {
      ...data,
      id,
      timestamp: new Date(),
    };
    this.marketData.set(id, marketData);
    return marketData;
  }

  async getSystemStatus(): Promise<SystemStatus | undefined> {
    return this.systemStatus;
  }

  async updateSystemStatus(status: InsertSystemStatus): Promise<SystemStatus> {
    if (this.systemStatus) {
      this.systemStatus = {
        ...this.systemStatus,
        ...status,
        lastUpdate: new Date(),
      };
    } else {
      this.systemStatus = {
        id: randomUUID(),
        ...status,
        lastUpdate: new Date(),
      };
    }
    return this.systemStatus;
  }
}

export const storage = new MemStorage();

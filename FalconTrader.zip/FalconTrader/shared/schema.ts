import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, timestamp, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const trades = pgTable("trades", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  pair: text("pair").notNull(), // e.g., "ETH/USDC"
  type: text("type").notNull(), // "BUY" or "SELL"
  amount: decimal("amount").notNull(),
  price: decimal("price").notNull(),
  status: text("status").notNull(), // "EXECUTED", "PENDING", "FAILED", "STOPPED"
  reason: text("reason").notNull(),
  executedAt: timestamp("executed_at").defaultNow(),
  pnl: decimal("pnl"),
  recallTxId: text("recall_tx_id"),
});

export const portfolio = pgTable("portfolio", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  totalValue: decimal("total_value").notNull(),
  dailyPnL: decimal("daily_pnl").notNull(),
  totalReturn: decimal("total_return").notNull(),
  totalReturnPercent: decimal("total_return_percent").notNull(),
  openPositions: integer("open_positions").notNull().default(0),
  maxPositions: integer("max_positions").notNull().default(5),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const positions = pgTable("positions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  pair: text("pair").notNull(),
  amount: decimal("amount").notNull(),
  entryPrice: decimal("entry_price").notNull(),
  currentPrice: decimal("current_price").notNull(),
  unrealizedPnL: decimal("unrealized_pnl").notNull(),
  unrealizedPnLPercent: decimal("unrealized_pnl_percent").notNull(),
  openedAt: timestamp("opened_at").defaultNow(),
});

export const strategyConfig = pgTable("strategy_config", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  isActive: boolean("is_active").notNull().default(true),
  fastSMA: integer("fast_sma").notNull().default(12),
  slowSMA: integer("slow_sma").notNull().default(26),
  atrPeriod: integer("atr_period").notNull().default(14),
  maxRiskPerTrade: decimal("max_risk_per_trade").notNull().default("1.0"),
  dailyLossLimit: decimal("daily_loss_limit").notNull().default("5.0"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const riskMetrics = pgTable("risk_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  currentRiskPerTrade: decimal("current_risk_per_trade").notNull(),
  dailyLossPercent: decimal("daily_loss_percent").notNull(),
  positionSlots: integer("position_slots").notNull(),
  maxDrawdown: decimal("max_drawdown").notNull(),
  sharpeRatio: decimal("sharpe_ratio").notNull(),
  winRate: decimal("win_rate").notNull(),
  profitFactor: decimal("profit_factor").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const competitionData = pgTable("competition_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  currentRank: integer("current_rank").notNull(),
  totalParticipants: integer("total_participants").notNull(),
  daysRemaining: decimal("days_remaining").notNull(),
  leaderPnL: decimal("leader_pnl").notNull(),
  prizePool: decimal("prize_pool").notNull().default("10000"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const marketData = pgTable("market_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  pair: text("pair").notNull(),
  price: decimal("price").notNull(),
  volume24h: decimal("volume_24h").notNull(),
  change24h: decimal("change_24h").notNull(),
  change24hPercent: decimal("change_24h_percent").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const systemStatus = pgTable("system_status", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  recallApiStatus: text("recall_api_status").notNull().default("online"),
  marketDataStatus: text("market_data_status").notNull().default("live"),
  lastUpdate: timestamp("last_update").defaultNow(),
  latencyMs: integer("latency_ms").notNull().default(0),
});

// Insert schemas
export const insertTradeSchema = createInsertSchema(trades).omit({ id: true, executedAt: true });
export const insertPortfolioSchema = createInsertSchema(portfolio).omit({ id: true, updatedAt: true });
export const insertPositionSchema = createInsertSchema(positions).omit({ id: true, openedAt: true });
export const insertStrategyConfigSchema = createInsertSchema(strategyConfig).omit({ id: true, updatedAt: true });
export const insertRiskMetricsSchema = createInsertSchema(riskMetrics).omit({ id: true, updatedAt: true });
export const insertCompetitionDataSchema = createInsertSchema(competitionData).omit({ id: true, updatedAt: true });
export const insertMarketDataSchema = createInsertSchema(marketData).omit({ id: true, timestamp: true });
export const insertSystemStatusSchema = createInsertSchema(systemStatus).omit({ id: true, lastUpdate: true });

// Types
export type Trade = typeof trades.$inferSelect;
export type InsertTrade = z.infer<typeof insertTradeSchema>;
export type Portfolio = typeof portfolio.$inferSelect;
export type InsertPortfolio = z.infer<typeof insertPortfolioSchema>;
export type Position = typeof positions.$inferSelect;
export type InsertPosition = z.infer<typeof insertPositionSchema>;
export type StrategyConfig = typeof strategyConfig.$inferSelect;
export type InsertStrategyConfig = z.infer<typeof insertStrategyConfigSchema>;
export type RiskMetrics = typeof riskMetrics.$inferSelect;
export type InsertRiskMetrics = z.infer<typeof insertRiskMetricsSchema>;
export type CompetitionData = typeof competitionData.$inferSelect;
export type InsertCompetitionData = z.infer<typeof insertCompetitionDataSchema>;
export type MarketData = typeof marketData.$inferSelect;
export type InsertMarketData = z.infer<typeof insertMarketDataSchema>;
export type SystemStatus = typeof systemStatus.$inferSelect;
export type InsertSystemStatus = z.infer<typeof insertSystemStatusSchema>;

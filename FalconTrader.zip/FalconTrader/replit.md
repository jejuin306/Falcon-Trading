# Overview

This is a smart momentum trading dashboard built for cryptocurrency trading competitions. The application features a real-time trading interface that displays portfolio performance, active positions, trading history, and strategy configuration. The system integrates with external trading APIs to execute automated trades based on technical indicators like Simple Moving Averages (SMA) and Average True Range (ATR).

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built with React and TypeScript using Vite as the build tool. The UI leverages shadcn/ui components with Radix UI primitives for accessibility and Tailwind CSS for styling. The application uses a single-page architecture with wouter for client-side routing.

**Key Design Decisions:**
- **Component Structure**: Modular component design with dedicated components for Header, Sidebar, Chart Area, Stats Grid, and Trade Log
- **State Management**: React Query for server state management with WebSocket integration for real-time updates
- **Styling Approach**: Dark theme optimized for trading with custom CSS variables and a professional color scheme
- **Responsive Design**: Mobile-first approach with desktop-optimized layouts for trading dashboards

## Backend Architecture
The backend uses Express.js with TypeScript in ESM module format. It implements a RESTful API structure with WebSocket support for real-time data streaming.

**Key Design Decisions:**
- **API Pattern**: RESTful endpoints with WebSocket broadcasting for live updates
- **Storage Abstraction**: Interface-based storage layer supporting both in-memory and database implementations
- **Real-time Communication**: WebSocket server for pushing trade executions, portfolio updates, and market data
- **Error Handling**: Centralized error middleware with structured error responses

## Database Design
The application uses Drizzle ORM with PostgreSQL for data persistence. The schema includes tables for trades, portfolio state, positions, strategy configuration, risk metrics, competition data, market data, and system status.

**Key Design Decisions:**
- **ORM Choice**: Drizzle ORM for type-safe database operations with Zod schema validation
- **Schema Structure**: Normalized tables with UUID primary keys and timestamp tracking
- **Data Types**: Decimal types for financial precision, JSONB for flexible configuration storage
- **Migration Strategy**: Drizzle Kit for schema migrations and database management

## External Service Integration
The system integrates with Recall Network's trading API for executing cryptocurrency trades in competition environments.

**Key Design Decisions:**
- **API Abstraction**: Service layer pattern for external API integration with error handling
- **Environment Configuration**: Separate sandbox and production API endpoints
- **Authentication**: Bearer token authentication for secure API access
- **Trade Execution**: Asynchronous trade processing with status tracking and rollback capabilities

## Real-time Data Flow
The application implements a WebSocket-based real-time data system that broadcasts updates to all connected clients when trades are executed or portfolio metrics change.

**Key Design Decisions:**
- **WebSocket Implementation**: Native WebSocket with automatic reconnection and connection state management
- **Data Broadcasting**: Server-side event broadcasting to all connected clients
- **Update Strategy**: Incremental updates with full data refresh fallbacks
- **Client Synchronization**: Automatic data synchronization on WebSocket connection establishment

# External Dependencies

## Core Technologies
- **Database**: PostgreSQL with Neon serverless hosting
- **ORM**: Drizzle ORM with drizzle-zod for schema validation
- **Frontend Framework**: React 18 with TypeScript and Vite
- **Backend Framework**: Express.js with WebSocket support
- **UI Components**: shadcn/ui with Radix UI primitives and Tailwind CSS

## Trading Integration
- **Recall Network API**: Cryptocurrency trading execution and competition management
- **Market Data**: Integration points for real-time price feeds and technical indicators

## Development Tools
- **Build System**: Vite for frontend bundling and development server
- **Type Safety**: TypeScript with strict configuration across frontend and backend
- **Styling**: Tailwind CSS with PostCSS processing and custom design tokens
- **Development Environment**: Replit-optimized configuration with hot reload support

## Third-party Services
- **Query Management**: TanStack React Query for server state and caching
- **Form Handling**: React Hook Form with Hookform Resolvers for validation
- **Date Management**: date-fns for date formatting and manipulation
- **Session Management**: connect-pg-simple for PostgreSQL session storage